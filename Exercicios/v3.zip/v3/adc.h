#ifndef  __ADC_H
#define  __ADC_H

#include <msp430.h>
#include <stdint.h>


uint16_t adcRead(uint8_t port);

#endif
