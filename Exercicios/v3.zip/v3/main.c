#include <msp430.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "uart.h"
#include "adc.h"
#include "lcd.h"

#define TERM_CLR "\033[2J"
#define TERM_HOME "\033[0;0H"
#define MAX_CH      8
#define TX          6,0
#define RX          6,1
#define TB          833,us

volatile uint8_t rxBuff[12];
volatile uint8_t i;
volatile uint16_t adcResult;
volatile uint16_t ch;
volatile char linha[17];
volatile uint16_t flag;

/**
 * main.c
 */
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    TA0CCTL0 = MC__UP | TASSEL__SMCLK;
    TA0CCR0  = 100 - 1;
    TA0CCTL0 = CCIE;

    i2cConfig();
    uint8_t zero = 0;
    i2cSend(0x3f, &zero, 1);

    lcdInit();
    adcRead(6);
    uartOpen(1);

    __enable_interrupt();
    i = MAX_CH;

    while(1){
        i = 8;
        while(i--)
        {
        adcResult = adcRead(i);
        sprintf(linha, "%d: %03x \n\r",  i ,adcResult);
        if (i == 0)
            lcdPrint(linha);
        uartPrint(linha);
        }
    }

}

#pragma vector = TIMER0_A0_VECTOR
__interrupt void TA1_CCR0_ISR(){
    while(i--){
        linha[i] &= ADC12EOS;
        linha[MAX_CH-1] |= ADC12EOS;
        flag = 1 << (MAX_CH - 1);
        while(!(ADC12IFG & flag));
    }
}

#pragma vector = ADC12_VECTOR
__interrupt void ADC_RESULT(){
    adcResult = ADC12MEM0;
}

